package telas_componentes;

public abstract class TituloJanela {
    public static final String TITULO_JANELA="Lucas Vinicius Sampaio Lima";
}