package lucas_vinicius;

import telas.*;
/**
 * @author Lucas Vinicius Sampaio Lima
 * RA:20026518-5
 * CURSO: BACHARELADO EM ENGENHARIA DE SOFTWARE
 * DISCIPLINA:PROGRAMAÇÃO DE SISTEMAS II 
 * MAPA - ESOFT - PROGRAMAÇÃO DE SISTEMAS II - 54/2022
 */
public class main {

    public static void main(String args[]) {
       new TelaInicial();
    }
}
